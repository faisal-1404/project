
<!DOCTYPE html>
<html lang="en">
<head>
    <title>admin</title>
    <link rel="stylesheet" href="./admin.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="form">
                <h3>Admin Login</h3>
                <form method="POST" action="">
                    <label>username</label><br/>
                    <input type="text" placeholder="username" name='username'autocomplete="off" /><br/>
                    <label>password</label><br/>
                    <input type="password" placeholder="password" name='password' autocomplete="off" /><br/>
                    <button class="button" name='submit'>submit</button>
                </form>
            </div>
        </div>
    </div>
    <?php
        if(isset($_POST['submit'])){
            $username=$_POST['username'];
            $password=$_POST['password'];
            if($username=='admin' && $password=='admin'){
                echo '<script>alert("login successfully")</script>';
                echo '<script>window.location.assign("http://localhost/women%20safety/admin_notification/admin_notification.php")</script>';
            }

            else{
                echo '<script>alert("Invalid Username and Password")</script>';
            }
        }
    ?>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>