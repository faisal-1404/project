<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <link rel="stylesheet" href="./home.css" />
    <link rel='stylesheet' href="./css/bootstrap.min.css" />
</head>
<body>
    <?php 
        include 'navbar.php';
    ?>
    <!-- <div class="title">
        <h2>WOMEN SAFETY</h2>
        <p></p>
        <p></p>
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Select Option
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="./../admin/admin.php">Admin</a></li>
                <li><a class="dropdown-item" href="./../user/user.php">User</a></li>
            </ul>
        </div>
    </div> -->
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/bootstrap.bundle.js"></script>
</body>
</html>
