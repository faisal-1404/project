
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Complaint Application</title>
    <link rel="stylesheet" href="./complaint.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="form">
                <h3>Complaint Application</h3>
                <form action="" method="POST" enctype="multipart/form-data">
                    <label>Upload image</label>
                    <input type="file" id="file" accept="image/*" name="image"/>
                    <label for="file" class="file">
                        <i class="fa-solid fa-file"></i>&nbsp;choosen file
                    </label><br/>
                    <label>Email</label><br/>
                    <input type="email" placeholder="Enter Your Email" name='email' autocomplete="off" /><br/>
                    <label>Complaint Message</label><br/>
                    <textarea rows="5" cols="43" class="content" name="reason" autocomplete="off"></textarea><br/>
                    <button class="button" name="submit">Submit</button>
                </form>
            </div>
            <?php
                if(isset($_POST['submit'])){
                    $email=$_POST['email'];
                    $reason=$_POST['reason'];

                    $newfolder="image/";

                    $file_target=$newfolder.basename($_FILES["image"]['name']);
                    $imagefiletype=strtolower(pathinfo($file_target,PATHINFO_EXTENSION));

                    if(file_exists($file_target)){
                        echo "<script>alert('file already exists')</script>";
                    }

                    else if($imagefiletype!="jpg"){
                        echo "<script>alert('jpg file only allowed')</script>";
                    }

                    else{

                        move_uploaded_file($_FILES["image"]['tmp_name'],$file_target);

                        $con=mysqli_connect('localhost','root','','women_safety');
                        $query="INSERT INTO complaints (image,email,reason) VALUES ('$file_target','$email','$reason')";
                        $check=mysqli_query($con,$query);

                        echo "<script>alert('Complaint Succesful Register')</script>";

                    }
                }
            ?>
        </div>
    </div>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>