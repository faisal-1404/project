<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>navbar</title>
    <link rel='stylesheet' href='./navbar.css' />
</head>
<body>
    <div class="title">
        <h2>WOMEN SAFETY</h2>
        <p></p>
        <p></p>
        <!-- <p></p> -->
        <!-- <select>
            <option value='Admin'>Admin</option>
            <option value="User">User</option>
        </select> -->
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Select Option
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="./../admin/admin.php">Admin</a></li>
                <li><a class="dropdown-item" href="./../user/user.php">User</a></li>
                <!-- <li><a class="dropdown-item" href="#">Something else here</a></li> -->
            </ul>
        </div>
    </div>
</body>
</html>