<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Danger Alert</title>
    <link
      rel="stylesheet"
      href="css\bootstrap.min.css"
    />
    <link rel="stylesheet" href="danger.css" />

  </head>
  <body>
    <div class="heading">
    <h1>DANGER ALERT</h1>
    </div>

    <div class="container-fluid">
      <table class="table table-warning">
        <thead>
          <tr>
            <th>Name</th>
            <th>Latitude</th>
            <th>longitude</th>
          </tr>
        </thead>
        <?php
          $con=mysqli_connect('localhost','root','','women_safety');
          $query="SELECT * FROM dangers";
          $result=mysqli_query($con,$query);
          while($row=mysqli_fetch_assoc($result)){
            echo "<tbody>
            <tr>
              <td>$row[username]</td>
              <td>$row[latitude]</td>
              <td>$row[longnitude]</td>
            </tr>
            </tbody>";
          }
        ?>
      </table>
    </div>


    <script src="js\bootstrap.min.js"></script>
  </body>
</html>
