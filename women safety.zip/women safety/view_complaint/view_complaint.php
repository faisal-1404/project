<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Complaint</title>
    <link rel='stylesheet' href='./view_complaint.css' />
    <link rel='stylesheet' href='./css/bootstrap.min.css' />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-2"></div>
            <div class="col-xl-8">
                <h3>Complaints</h3>
                <table class='table table-primary'>
                    <thead>
                        <tr>
                            <th scope='col'>Image</th>
                            <th scope='col'>Email</th>
                            <th scope='col'>Reason</th>
                            <th scope='col'>Reply</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php
                        $con=mysqli_connect('localhost','root','','women_safety');
                        $query="SELECT * FROM complaints";
                        $result=mysqli_query($con,$query);
                        while($row=mysqli_fetch_assoc($result)){
                            echo "
                            <tr>
                              <td><img src='../complaint/$row[image]' alt=img height=35px width=50px /></td>
                              <td>$row[email]</td>
                              <td>$row[reason]</td>
                              <form action='' method='POST'>
                                <td class='td'><input type=text class=form-control name='reply' autocomplete='off'/>
                                <button class='btn btn-primary' name='send' value='$row[email]'>Send</button></td>
                            </form>
                            </tr>";
                        }
                    ?>
                    </tbody>
                </table>

                <?php
                    if(isset($_POST["send"])){
                        $reply=$_POST["reply"];
                        $con=mysqli_connect('localhost','root','','women_safety');
                        $query="UPDATE complaints SET reply='$reply' where email='$_POST[send]'";
                        $result=mysqli_query($con,$query);
                    }
                ?>
            </div>
        </div>
    </div>
</body>
</html>