
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <link rel="stylesheet" href="./register.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
            <div class="form">
                <h3>Register Form</h3>
                <form method="POST" action="" enctype="multipart/form-data">
                    <label>Id</label><br/>
                    <input type="text" placeholder="Id" name='id' autocomplete="off" /><br/>
                    <label>Name</label><br/>
                    <input type="text" placeholder="Enter Your Name" name='name' autocomplete="off" /><br/>
                    <label>Age</label><br/>
                    <input type="number" placeholder="Enter Your Age" name='age' class="num" autocomplete="off" /><br/>
                    <label>Address</label><br/>
                    <textarea rows="5" cols="45" name='address' autocomplete="off" ></textarea><br/>
                    <label>Mobile</label><br/>
                    <input type="number" placeholder="Enter Your Mobile" name='mobile' class="num" autocomplete="off" /><br/>
                    <label>Email</label><br/>
                    <input type="email" placeholder="Enter Your Email" name='email' autocomplete="off" /><br/>
                    <input type="file" id="file" accept="image/*" name='image'/>
                    <label for="file" class="file">
                        <i class="fa-solid fa-file"></i>&nbsp;choosen file
                    </label><br/>
                    <button class="button" name='next'><b>Next</b></button>
                    <div class="guardian">
                        <label>Guardian 1</label><br/>
                        <input type='text' placeholder="Guardian Name" name='gname1'autocomplete="off" /><br/>
                        <input type='number' placeholder="Guardian Mobile" name='gmobile1' class="num" autocomplete="off" /><br/>
                        <label>Guardian 2</label><br/>
                        <input type='text' placeholder="Guardian Name" name='gname2' autocomplete="off" /><br/>
                        <input type='number' placeholder="Guardian Mobile" name='gmobile2' class="num" autocomplete="off" /><br/>
                        <label>Guardian 3</label><br/>
                        <input type='text' placeholder="Guardian Name" name='gname3' autocomplete="off" /><br/>
                        <input type='number' placeholder="Guardian Mobile" name='gmobile3' class="num" autocomplete="off"/><br/>
                        <label>Guardian 4</label><br/>
                        <input type='text' placeholder="Guardian Name" name='gname4' autocomplete="off"/><br/>
                        <input type='number' placeholder="Guardian Mobile" name='gmobile4' class="num" autocomplete="off"/><br/>
                        <label>Guardian 5</label><br/>
                        <input type='text' placeholder="Guardian Name" name='gname5' autocomplete="off"/><br/>
                        <input type='number' placeholder="Guardian Mobile" name='gmobile5' class="num" autocomplete="off"/><br/>
                    </div>
                </form>
            </div>
        </div>
        </div>
    </div>
    <?php
        if(isset($_POST['next'])){
            $reg_id=$_POST['id'];
            $name=$_POST['name'];
            $age=$_POST['age'];
            $address=$_POST['address'];
            $mobile=$_POST['mobile'];
            $email=$_POST['email'];
            $gname_1=$_POST['gname1'];
            $gmobile_1=$_POST['gmobile1'];
            $gname_2=$_POST['gname2'];
            $gmobile_2=$_POST['gmobile2'];
            $gname_3=$_POST['gname3'];
            $gmobile_3=$_POST['gmobile3'];
            $gname_4=$_POST['gname4'];
            $gmobile_4=$_POST['gmobile4'];
            $gname_5=$_POST['gname5'];
            $gmobile_5=$_POST['gmobile5'];


            if($reg_id==""){
                echo "<script>alert('fill the id')</script>";
            }

            else if(!preg_match("/^[a-zA-Z0-9]/",$reg_id)){
                echo "<script>alert('id do not other character allowed')</script>";
            }

            if(empty($name)){
                echo "<script>alert('fill the name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$name)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($age==""){
                echo "<script>alert('fill the age')</script>";
            }

            else if(!preg_match("/^[0-9]/",$age)){
                echo "<script>alert('age numbers only allowed')</script>";
            }

            if($address==""){
                echo "<script>alert('fill the address')</script>";
            }

            else if(!preg_match("/^[A-Za-z0-9]/",$address)){
                echo "<script>alert('address do not other character allowed')</script>";
            }

            if($mobile==""){
                echo "<script>alert('fill the phone')</script>";
            }

            else if(!preg_match("/^[0-9]/",$mobile)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($mobile)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            if($email==""){
                echo "<script>alert('fill the email')</script>";
            }

            else if(!preg_match("/^[a-zA-Z0-9]/",$email)){
                echo "<script>alert('email do not other character allowed')</script>";
            }

            if(empty($gname_1)){
                echo "<script>alert('fill the guardian name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$gname_1)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($gmobile_1==""){
                echo "<script>alert('fill the guardian mobile')</script>";
            }

            else if(!preg_match("/^[0-9]/",$gmobile_1)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($gmobile_1)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            if(empty($gname_2)){
                echo "<script>alert('fill the guardian name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$gname_2)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($gmobile_2==""){
                echo "<script>alert('fill the guardian mobile')</script>";
            }

            else if(!preg_match("/^[0-9]/",$gmobile_2)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($gmobile_2)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            if(empty($gname_3)){
                echo "<script>alert('fill the guardian name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$gname_3)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($gmobile_3==""){
                echo "<script>alert('fill the guardian mobile')</script>";
            }

            else if(!preg_match("/^[0-9]/",$gmobile_3)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($gmobile_3)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            if(empty($gname_4)){
                echo "<script>alert('fill the guardian name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$gname_4)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($gmobile_4==""){
                echo "<script>alert('fill the guardian mobile')</script>";
            }

            else if(!preg_match("/^[0-9]/",$gmobile_4)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($gmobile_4)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            if(empty($gname_5)){
                echo "<script>alert('fill the guardian name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$gname_5)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($gmobile_5==""){
                echo "<script>alert('fill the guardian mobile')</script>";
            }

            else if(!preg_match("/^[0-9]/",$gmobile_5)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($gmobile_5)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            $newfolder="image/";

            $file_target=$newfolder.basename($_FILES["image"]['name']);
            $imagefiletype=strtolower(pathinfo($file_target,PATHINFO_EXTENSION));

            if(file_exists($file_target)){
                echo "<script>alert('file already exists')</script>";
            }

            else if($imagefiletype!="jpg"){
                echo "<script>alert('jpg file only allowed')</script>";
            }

            else{

                move_uploaded_file($_FILES["image"]['tmp_name'],$file_target);

                $con=mysqli_connect('localhost','root','','women_safety');

                $query="INSERT into register_forms (reg_id,name,age,address,mobile,email,image,g_name_1,g_mobile_1,g_name_2,g_mobile_2,
                g_name_3,g_mobile_3,g_name_4,g_mobile_4,g_name_5,g_mobile_5,date) VALUES ($reg_id,'$name','$age','$address','$mobile','$email',
                '$file_target','$gname_1','$gmobile_1','$gname_2','$gmobile_2','$gname_3','$gmobile_3','$gname_4','$gmobile_4',
                '$gname_5','$gmobile_5',curdate())";

                $check=mysqli_query($con,$query);

                // echo "<script>window.location.assign('http://localhost/task/project/women%20safety/project/guardian_1/guardian_1.php')</script>";
                echo "<script>alert('Register Successfully')</script>";
            }

                
        

        }
    ?> -->
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>