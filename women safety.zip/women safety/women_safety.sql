-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2023 at 05:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `women_safety`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `image` varchar(150) NOT NULL,
  `email` varchar(30) NOT NULL,
  `reason` varchar(300) NOT NULL,
  `reply` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `image`, `email`, `reason`, `reply`) VALUES
(6, 'image/hand_2.jpg', 'mohamed0804@gmail.com', 'jkkkj', 'dkflkdfk'),
(7, 'image/hand_2.jpg', 'faisalahamed0804@gmail.com', 'sklklklaksd', 'eklwkkek'),
(8, 'image/database.jpg', 'mohamed0804@gmail.com', 'hjhhhhj', 'dkflkdfk'),
(11, 'image/amazon-5.jpg', 'fayas@gmail.com', 'road rummers are ragging are mothilal street', 'kklewklewk'),
(12, 'image/women image.jpg', 'fayas@gmail.com', 'jjkdjkdfjjfjdfk', 'kklewklewk'),
(13, 'image/thumb.jpg', 'sameer@gmail.com', 'rioerioierioerrerjfjr', 'kfjldffjkjlfjkkjks;j'),
(14, 'image/IMG-20230407-WA0007.jpg', 'shahul@gmail', 'ragging for me', 'i will come immediately'),
(15, 'image/vaseline.jpg', 'shahul@gmail.com', 'ejwjewdnwkldjlk;jakk', 'hdsfjhfsdhjlfhal'),
(16, 'image/cleaning.jpg', 'fff@gmail.com', 'djdjj', 'wait'),
(17, 'image/splitting data into two.jpg', 'askar@gmail.com', 'thief are attacked me', 'share your current location and i call police patrol in your current location');

-- --------------------------------------------------------

--
-- Table structure for table `dangers`
--

CREATE TABLE `dangers` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longnitude` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dangers`
--

INSERT INTO `dangers` (`id`, `username`, `latitude`, `longnitude`) VALUES
(1, 'fayas', 'Latitude: 10.9645004', 'Longitude: 79.3915941'),
(2, 'sameer', 'Latitude: 10.9603535', 'Longitude: 79.3917935'),
(0, 'askar', 'Latitude: 11.304271', 'Longitude: 79.5613329');

-- --------------------------------------------------------

--
-- Table structure for table `register_forms`
--

CREATE TABLE `register_forms` (
  `id` int(11) NOT NULL,
  `reg_id` int(4) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(3) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `image` varchar(150) NOT NULL,
  `g_name_1` varchar(20) NOT NULL,
  `g_mobile_1` bigint(10) NOT NULL,
  `g_name_2` varchar(20) NOT NULL,
  `g_mobile_2` bigint(10) NOT NULL,
  `g_name_3` varchar(20) NOT NULL,
  `g_mobile_3` bigint(10) NOT NULL,
  `g_name_4` varchar(20) NOT NULL,
  `g_mobile_4` bigint(10) NOT NULL,
  `g_name_5` varchar(20) NOT NULL,
  `g_mobile_5` bigint(10) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register_forms`
--

INSERT INTO `register_forms` (`id`, `reg_id`, `name`, `age`, `address`, `mobile`, `email`, `image`, `g_name_1`, `g_mobile_1`, `g_name_2`, `g_mobile_2`, `g_name_3`, `g_mobile_3`, `g_name_4`, `g_mobile_4`, `g_name_5`, `g_mobile_5`, `date`, `status`) VALUES
(2, 1001, 'faisal', 22, 'kumbakonam', 9600847668, 'fff@gmail.com', 'image/fayas.jpg', '', 0, '', 0, '', 0, '', 0, '', 0, '0000-00-00', 0),
(3, 1002, 'fayas', 21, 'gon', 9600847668, 'fayas@gmail.com', 'image/database.jpg', '', 0, '', 0, '', 0, '', 0, '', 0, '0000-00-00', 0),
(4, 1111, 'anaz', 18, 'thiruvarur', 9600847668, 'fff@gmail.com', 'image/hand_1.jpg', '', 0, '', 0, '', 0, '', 0, '', 0, '0000-00-00', 0),
(6, 1008, 'aris', 16, 'chennai', 8520147963, 'mohamed0804@gmail.com', 'image/mixer.jpg', '', 0, '', 0, '', 0, '', 0, '', 0, '0000-00-00', 0),
(7, 1112, 'sanjay', 18, 'chidambaram', 1234567890, 'fayas@gmail.com', 'image/amazon-1.jpg', 'arrr', 1234567890, 'nansj', 1234567890, 'hshdhd', 1234567890, 'hdhdh', 1234567890, 'sjdjjs', 1234567890, '0000-00-00', 0),
(8, 1120, 'varun', 22, 'cuddalore', 123456789, 'varun@gmail.com', 'image/amazon-5.jpg', 'arrr', 1234567890, 'nansj', 1234567890, 'hshdhd', 1234567890, 'ggggg', 7894561230, 'sjdjjs', 7894561230, '2023-04-20', 0),
(9, 1121, 'sameer', 19, 'kovai', 1230456789, 'sameer@gmail.com', 'image/amazon-3.jpg', 'arrr', 1234567890, 'nansj', 1234567890, 'hhjdh', 1234567890, 'hdhdh', 1234567890, 'sjdjjs', 1234567890, '2023-04-20', 0),
(10, 1125, 'shahul', 22, 'cuddalore', 9876543210, 'shahul@gmail.com', 'image/IMG-20230407-WA0007.jpg', 'sameer', 1234567890, 'anaz', 1234567890, 'aris', 1234567890, 'fayas', 1234567890, 'arif', 1234567890, '2023-04-28', 0),
(0, 1052, 'askar', 22, 'lalpet', 7871836048, 'askar@gmail.com', 'image/splitting data into two.jpg', 'askar', 7871836048, 'askar', 7871836048, 'askar', 7871836048, 'askar', 7871836048, 'askar', 7871836048, '2023-11-29', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
