
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Guardian</title>
    <link rel="stylesheet" href="./guardian_5.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="form">
                <h3>Guardian Form</h3>
                <form method='POST' action='' enctype='multipart/form-data'>
                    <label>Name</label><br/>
                    <input type="text" placeholder="Enter Your Name" name='name'/><br/>
                    <label>Address</label><br/>
                    <textarea rows="5" cols="45" name='address'></textarea><br/>
                    <label>Mobile</label><br/>
                    <input type="number" placeholder="Enter Your Mobile" name='mobile' class="num"/><br/>
                    <label>Email</label><br/>
                    <input type="email" placeholder="Enter Your Email" name='email' /><br/>
                    <input type="file" id="file" accept="image/*" name='image'/>
                    <label for="file" class="file">
                        <i class="fa-solid fa-plus"></i>&nbsp;choosen file
                    </label><br/>
                    <button class="button" name='submit'><b>Submit</b></button>
                </form>
            </div>
        </div>
    </div>
    <?php
        if(isset($_POST['submit'])){
            $name=$_POST['name'];
            $address=$_POST['address'];
            $mobile=$_POST['mobile'];
            echo $address;
            $email=$_POST['email'];

            if(empty($name)){
                echo "<script>alert('fill the name')</script>";
            }

            else if(!preg_match("/^[a-zA-Z]/",$name)){
                echo "<script>alert('name character only allowed')</script>";
            }

            if($address==""){
                echo "<script>alert('fill the address')</script>";
            }

            else if(!preg_match("/^[A-Za-z0-9]/",$address)){
                echo "<script>alert('address do not other character allowed')</script>";
            }

            if($mobile==""){
                echo "<script>alert('fill the phone')</script>";
            }

            else if(!preg_match("/^[0-9]/",$mobile)){
                echo "<script>alert('phone numbers only allowed')</script>";
            }

            else if(strlen($mobile)!=10){
                echo "<script>alert('phone number is too large')</script>";
            }

            if($email==""){
                echo "<script>alert('fill the email')</script>";
            }

            else if(!preg_match("/^[a-zA-Z0-9]/",$email)){
                echo "<script>alert('email do not other character allowed')</script>";
            }

            $newfolder="image/";

            $file_target=$newfolder.basename($_FILES["image"]['name']);
            $imagefiletype=strtolower(pathinfo($file_target,PATHINFO_EXTENSION));

            if(file_exists($file_target)){
                echo "<script>alert('file already exists')</script>";
            }

            else if($imagefiletype!="jpg"){
                echo "<script>alert('jpg file only allowed')</script>";
            }

            else{
                move_uploaded_file($_FILES["image"]['tmp_name'],$file_target);

                $con=mysqli_connect('localhost','root','','women_safety');

                $query="INSERT into guardian_5 (name,address,mobile,email,image) values ('$name','$address','$mobile','$email','$file_target')";

                $check=mysqli_query($con,$query);

                echo "<script>alert('your form has been successfully submitted')</script>";
                echo '<script>window.location.assign("http://localhost/task/project/women%20safety/project/user/user.php")</script>';
            }
        }
    ?>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>