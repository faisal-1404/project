<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>user</title>
    <link rel="stylesheet" href="./user.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <style>
        .btn{
            background-color: blue;
            width:130px;
            border:none;
            font-weight: bold;
            border-radius: 10px;
            color:white;
            margin-top: 20px;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="form">
                <h3>User Login</h3>
                <form method='POST' action=''>
                    <label>username</label><br/>
                    <input type="text" placeholder="username" name='username' autocomplete="off" /><br/>
                    <label>password</label><br/>
                    <input type="password" placeholder="password" name='password' autocomplete="off" /><br/>
                    <small class="user">New User <a href="./../register/register.php">Register Now</a></small><br/>
                    <button class="btn" name='submit'>submit</button>
                </form>
            </div>
        </div>
    </div>
    <?php
        if(isset($_POST['submit'])){
            $username=$_POST['username'];
            $password=$_POST['password'];
            $status;
            $con=mysqli_connect('localhost','root','','women_safety');
            $sql="select * from register_forms where name='$username' and mobile='$password' ";
            $result=mysqli_query($con,$sql);
           $fetch=mysqli_fetch_assoc($result);

                if(mysqli_num_rows($result)>0){
                    if($fetch['status']==1)
                    {
                        echo "<script>alert('This user is Not Allowed')</script>";

                    }
                    else
                    {
                        echo $fetch['email'];
                        $_SESSION['mail']=$fetch['email'];
                        $_SESSION['username']=$username;
                        echo "<script>window.location.assign('http://localhost/women%20safety/user_dashboard/dashborad.php')</script>";
                    
                    }
                
                }
               
            
        }
    ?>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>