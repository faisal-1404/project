<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dash Board</title>
    <link rel="stylesheet" href="./dashbord.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  </head>
  <body>
    <div class="sidebar">
      <div class="full">
        <div class="sidebar-brand">
          <h1>Profile</h1>
        </div>
  
        <div class="sidebar-menu">
          <?php
         
            $con=mysqli_connect('localhost','root','','women_safety');
            if(!$con){
              die('connection error'.mysqli_connect_error());
            }

            $query = "SELECT*FROM register_forms where name='$_SESSION[username]' ";
            $result=mysqli_query($con,$query);
            $numrow=mysqli_num_rows($result);
            $row=mysqli_fetch_assoc($result);
            if($numrow==1){
                
            ?>
            <div class="image">
              <img class="img-1" src="../register/<?php echo $row['image'];?>" alt="" />
            </div>
          <ul>
            <li>
              <span>Id &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <?php echo $row['reg_id'];?></span>
            </li>
            <li>
              <span>Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <?php echo $row['name'];?></span>
            </li>
            <li>
              <span
                >Age &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $row['age'];?></span
              >
            </li>
            <li>
              <span>Address &nbsp;&nbsp;&nbsp;: <?php echo $row['address'];?></span>
            </li>
            <li>
              <span>Mobile &nbsp;&nbsp;&nbsp;&nbsp; : <?php echo $row['mobile'];?></span>
            </li>
            <li>
              <span>Email &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <?php echo $row['email'];?></span>
            </li>
          </ul>
        </div>
      </div>
      <button class="button"><a href='./../complaint/complaint.php'><i class="fa-solid fa-newspaper i1"></i>&nbsp;&nbsp;complaint</a></button>
    </div>
    <?php
            }
            ?>

    <div class="title">
      <h2>Gardient List</h2>
      <div class="icon">
      <!-- <button class='button2'><a href='./../complaint/complaint.php'><i class="fa-regular fa-envelope b2"></i></a></button> -->
      <button class='button2'><a href='./../user_notification/user_notification.php'><i class="fa-regular fa-bell b2"></i></a></button>
      </div>
    </div>
    <div class="click">
        <button onclick="getLocation()" class="button1" >
        <i class="fa-solid fa-triangle-exclamation b1"></i></i><br/><b> Danger </b></button><br/>
<!-- <p id="demo"></p> -->
      </div>

      <div class="location">
        <form action="" method="POST">
          <label>Location </label><br/>
            <textarea id="demo" cols="30" rows="2" name="latitude" class="lan" ></textarea>
            <br>
            <textarea id="demo1" cols="30" rows="2" name="longnitude" class="lan lon" ></textarea><br/>
            <button name="share"><i class="fa-solid fa-location-dot i1"></i>&nbsp;&nbsp;Share Location</button>
        </form>
      </div>

      <?php
        if(isset($_POST["share"])){
          $latitude=$_POST["latitude"];
          $longnitude=$_POST["longnitude"];
          
          $con=mysqli_connect('localhost','root','','women_safety');
          $query="INSERT INTO dangers (username,latitude,longnitude) VALUES ('$_SESSION[username]','$latitude','$longnitude')";
          $result=mysqli_query($con,$query);
        }
      ?>


    <div class="p">
      <div class="first-div">
        <!-- <img src="./asset/back.jpg" class="img-2" alt="" /> -->
        <div class="details">
          <h5>&nbsp;&nbsp;Name&nbsp;&nbsp;:&nbsp;<?php echo $row['g_name_1'];?></h5><br/>
          <h5>Mobile : <?php echo $row['g_mobile_1'];?> </h5>
        </div>
      </div>
    </div>

    <div class="p">
      <div class="first-div">
        <!-- <img src="./asset/back.jpg" class="img-2" alt="" /> -->
        <div class="details">
          <h5>&nbsp;&nbsp;Name&nbsp;&nbsp;:&nbsp;<?php echo $row['g_name_2'];?></h5><br/>
          <h5>Mobile : <?php echo $row['g_mobile_2'];?> </h5>
        </div>
      </div>
    </div>

    <div class="p">
      <div class="first-div">
        <!-- <img src="./asset/back.jpg" class="img-2" alt="" /> -->
        <div class="details">
          <h5>&nbsp;&nbsp;Name&nbsp;&nbsp;:&nbsp;<?php echo $row['g_name_3'];?></h5><br/>
          <h5>Mobile : <?php echo $row['g_mobile_3'];?> </h5>
        </div>
      </div>
    </div>

    <div class="p">
      <div class="first-div">
        <!-- <img src="./asset/back.jpg" class="img-2" alt="" /> -->
        <div class="details">
          <h5>&nbsp;&nbsp;Name&nbsp;&nbsp;:&nbsp;<?php echo $row['g_name_4'];?></h5><br/>
          <h5>Mobile : <?php echo $row['g_mobile_4'];?> </h5>
        </div>
      </div>
    </div>

    <div class="p">
      <div class="first-div">
        <!-- <img src="./asset/back.jpg" class="img-2" alt="" /> -->
        <div class="details">
          <h5>&nbsp;&nbsp;Name&nbsp;&nbsp;:&nbsp;<?php echo $row['g_name_5'];?></h5><br/>
          <h5>Mobile : <?php echo $row['g_mobile_5'];?> </h5>
        </div>
      </div>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
        var x = document.getElementById("demo");
        var x1 = document.getElementById("demo1");

        function getLocation() {
            x.innerHTML = "Please Wait.. We are loading your location";
          if (navigator.geolocation) {
            navigator.geolocation.watchPosition(showPosition);
          } else { 
            x.innerHTML = "Geolocation is not supported by this browser.";
            alert("hello");
          }
        }
            
        function showPosition(position) {
            x.innerHTML="Latitude: " + position.coords.latitude;
            x1.innerHTML="Longitude: " + position.coords.longitude;
          
          jQuery.ajax({
            type:'POST',
            url:'geocoordinates.php',
            data:'lat='+position.coords.latitude+'&lng='+position.coords.longitude,
            success:function(address){
              if(address){
                var encodedUrl = encodeURIComponent(address);
                jQuery("#location").html(address);
              }else{
                jQuery("#location").html('Not Available');
              }
            }
            });
          
        }

      </script>
  </body>
</html>
