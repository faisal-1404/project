
<!DOCTYPE html>
<html lang="en">
<head>
    <title>admin notification</title>
    <link rel="stylesheet" href="./admin_notification.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-4"></div>
            <div class="col-xl-5 form">
                <h3>Admin Notification</h3>
                <form action="" method="POST">
                    <button class="button" name="complaint">Complaint</button><br/>
                    <button class="button"><a href="../danger_alert/danger.php">Alert</a></button><br/>
                    <button class="button"><a href="../user_details/user_details.php">User Details</a></button><br/>
                    <button class="button"><a href="../admin/admin.php">Go Back</a></button>
                </form>
            </div>
        </div>
        <?php
            if(isset($_POST['complaint'])){
                echo "<script>window.location.assign('http://localhost/women%20safety/view_complaint/view_complaint.php')</script>";
            }
        ?>

    </div>
    <script src="./js/bootstrap.min.js"></script>
</body>