<?php
    session_start();
        $con=mysqli_connect('localhost','root','','women_safety');
        // echo "hi". $_SESSION['mail'];
        $select="select * from complaints where email='$_SESSION[mail]'";
        $result=mysqli_query($con,$select);
        $row=mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>user notification</title>
    <link rel="stylesheet" href="./user_notification.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="form">
                <h3>User Notification</h3>
                <form action="" method="POST">
                <table class='table table-primary'>
                    <thead>
                        <tr>
                            <th scope='col'>Message</th>
                            <th scope='col'>Reply</th>
                        </tr>
                    </thead>

                    <tbody>
                        <td><?php echo $row['reason'];?></td>
                        <td><?php echo $row['reply'];?></td>
                    </tbody>
                </table>
                    <!-- <input type="text" disabled/><br/>
                    <textarea rows="5" cols="43" class="content" disabled></textarea><br/> -->
                    <!-- <input type="button" value="submit" /> -->
                </form>
            </div>
        </div>
    </div>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>