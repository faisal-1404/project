<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link rel='stylesheet' href='./user_details.css' />
    <link rel='stylesheet' href='./css/bootstrap.min.css' />
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-2"></div>
            <div class="col-xl-8">
            <h3>User Details</h3>
                <table class='table table-primary'>
                    <thead>
                        <tr>
                            <th scope='col'>Register Id</th>
                            <th scope='col'>Name</th>
                            <th scope='col'>Age</th>
                            <th scope='col'>Address</th>
                            <th scope='col'>Mobile</th>
                            <th scope='col'>Email</th>
                            <th scope='col'>Block</th>
                            <th scope='col'>Unblock</th>
                        </tr>
                    </thead>

                    <?php
                        $con=mysqli_connect('localhost','root','','women_safety');
                        $query="SELECT * FROM register_forms";
                        $result=mysqli_query($con,$query);
                        while($row=mysqli_fetch_assoc($result)){
                        echo "<tbody>
                        <tr>
                            <td>$row[reg_id]</td>
                            <td>$row[name]</td>
                            <td>$row[age]</td>
                            <td>$row[address]</td>
                            <td>$row[mobile]</td>
                            <td>$row[email]</td>
                            <form method='POST'>
                            <td><button value=$row[reg_id] class='btn btn-danger' name='block'>Block</button></td>
                            <td><button value=$row[reg_id] class='btn btn-primary' name='unblock'>Unbock</button></td>
                            </form>
                        </tr>";
                        }

                        if(isset($_POST['block'])){
                            $con=mysqli_connect('localhost','root','','women_safety');
                            $query="SELECT * FROM register_forms WHERE reg_id=$_POST[block]";
                            $result=mysqli_query($con,$query);
                            while($row=mysqli_fetch_assoc($result)){
                               $_SESSION['status']=$row['status'];
                            }

                            if($_SESSION['status']==0){
                                $con=mysqli_connect('localhost','root','','women_safety');
                                $query="UPDATE register_forms SET status=1 WHERE reg_id='$_POST[block]'";
                                $result=mysqli_query($con,$query);
                                echo "<script>alert('User Blocked Successfully')</script>";
                            }

                            else{
                                echo "<script>alert('User Already Blocked')</script>";
                            }
                        }

                        if(isset($_POST['unblock'])){
                            $con=mysqli_connect('localhost','root','','women_safety');
                            $query="SELECT * FROM register_forms WHERE reg_id=$_POST[unblock]";
                            $result=mysqli_query($con,$query);
                            while($row=mysqli_fetch_assoc($result)){
                               $_SESSION['status']=$row['status'];
                            }

                            if($_SESSION['status']==1){
                                $con=mysqli_connect('localhost','root','','women_safety');
                                $query="UPDATE register_forms SET status=0 WHERE reg_id='$_POST[unblock]'";
                                $result=mysqli_query($con,$query);
                                echo "<script>alert('User Unblocked Successfully')</script>";
                            }

                            else{
                                echo "<script>alert('User Already Unblocked')</script>";
                            }
                        }
                    ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src='./js/bootstrap.min.js'></script>
</body>
</html>