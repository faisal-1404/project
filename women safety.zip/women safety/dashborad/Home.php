<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Home Website</title>
    <link rel="stylesheet" href="./Home.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href='./bootstrap-5.0.2-dist/css/bootstrap.min.css' />
    
  </head>
  <body>
    <div class="nav">
      <div class="logo"><span class="b-name">Women Safety</span></div>
      <div class="menu">
        <form action="" method="POST">
          <button name='all' class="button">All User List</button>
          <button name='new' class="button">New User</button>
          <button name='block' class="button">Block user</button>
        </form>
        <!-- <button class="button"><a href="./../admin_notification/admin_notification.php"><i class="fa-solid fa-bell"></i></a></button>
        <button class="button"><a href="./../danger_alert/danger.php"><i class="fa-solid fa-triangle-exclamation"></i></a></button> -->
      </div>
    </div>
    <?php
      if(isset($_POST['all'])){
        echo " <table class='table table-primary w-75 text-center mt-5' style=margin-left:210px>
        <thead>
          <tr>
            <th scope='col'>Reg Id</th>
            <th scope='col'>Name</th>
            <th scope='col'>Age</th>
            <th scope='col'>Address</th>
            <th scope='col'>Mobile</th>
            <th scope='col'>Email</th>            
          </tr>
        </thead>";
        $con=mysqli_connect('localhost','root','','women_safety');
        $query="SELECT * FROM register_form";
        $result=mysqli_query($con,$query);
      while($row=mysqli_fetch_assoc($result)){
        echo "
        <tbody>
        <tr>
          <td>$row[reg_id]</td>
          <td>$row[name]</td>
          <td>$row[age]</td>
          <td>$row[address]</td>
          <td>$row[mobile]</td>
          <td>$row[email]</td>
        </tr>
        </tbody>";
      }
    }

    if(isset($_POST['new'])){
      echo "<table class='table table-primary w-75 text-center mt-5' style=margin-left:210px>
      <thead>
        <tr>
          <th scope='col'>Reg Id</th>
          <th scope='col'>Name</th>
          <th scope='col'>Age</th>
          <th scope='col'>Address</th>
          <th scope='col'>Mobile</th>
          <th scope='col'>Email</th>
        </tr>
      </thead>";
      $con=mysqli_connect('localhost','root','','women_safety');
      $query="SELECT * FROM `register_form` WHERE date=curdate()";
      $result=mysqli_query($con,$query);
    while($row=mysqli_fetch_assoc($result)){
      echo "
      <tbody>
      <tr>
        <td>$row[reg_id]</td>
        <td>$row[name]</td>
        <td>$row[age]</td>
        <td>$row[address]</td>
        <td>$row[mobile]</td>
        <td>$row[email]</td>
      </tr>
      </tbody>";
    }
  }

  if(isset($_POST['block'])){
    echo "<form action='' method=POST>";
    echo "<table class='table table-primary w-75 text-center mt-5' style=margin-left:210px>
    <thead>
      <tr>
        <th scope='col'>Reg Id</th>
        <th scope='col'>Name</th>
        <th scope='col'>Age</th>
        <th scope='col'>Address</th>
        <th scope='col'>Mobile</th>
        <th scope='col'>Email</th>
        <th scope='col'>Block</th>
        <th scope='col'>Unblock</th>
      </tr>
    </thead>";
    $con=mysqli_connect('localhost','root','','women_safety');
    $query="SELECT * FROM `register_form`";
    $result=mysqli_query($con,$query);
  while($row=mysqli_fetch_assoc($result)){
    echo "
    <tbody>
    <tr>";
    ?>
      <td><?php echo $row['reg_id'];?></td>
      <td><?php echo $row['name'];?></td>
      <td><?php echo $row['age'];?></td>
      <td><?php echo $row['address'];?></td>
      <td><?php echo $row['mobile'];?></td>
      <td><?php echo $row['email'];?></td>
      <td><button class="btn btn-danger" name='BLOCK' value="<?php echo $row['reg_id']; ?>">Block</button></td>
      <td><button class="btn btn-primary" name='UNBLOCK' value="<?php echo $row['reg_id']; ?>">UNBLOCK</button></td>
      
    </tr>
    </tbody>

    <?php
    echo "</form>";
  }
}
   
    ?>
     </table>
    <script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
  if(isset($_POST['BLOCK'])){
    $con=mysqli_connect('localhost','root','','women_safety');
    $id=$_POST['BLOCK'];
    $query="SELECT * FROM register_form WHERE reg_id=$id";
    $result=mysqli_query($con,$query);
    $numrow=mysqli_num_rows($result);
    if($numrow==1){
      $update="UPDATE register_form SET status=1 WHERE reg_id=$id";
      $result=mysqli_query($con,$update);
      if($result)
      {
        echo "<script>alert('This User is Blocked')</script>";
      }
    }
  }

  if(isset($_POST['UNBLOCK'])){
    $con=mysqli_connect('localhost','root','','women_safety');
    $id=$_POST['UNBLOCK'];
    $query="SELECT * FROM register_form WHERE reg_id=$id";
    $result=mysqli_query($con,$query);
    $numrow=mysqli_num_rows($result);
    if($numrow==1){
      $update="UPDATE register_form SET status=0 WHERE reg_id=$id";
      $result=mysqli_query($con,$update);
      if($result)
      {
        echo "<script>alert('This User is Unblocked')</script>";
      }
    }
  }
?>