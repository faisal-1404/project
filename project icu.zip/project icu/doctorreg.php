
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>doctorregister</title>
    <link rel="stylesheet" href="doctorreg.css">
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css" />
</head>
<body>
<div class="container-fluid">
  
  <div class="row ">
 
  <div class="col-sm-12 col-md-12 col-lg-12 dg">
  <nav class="navbar navbar-expand-lg navbar-light   d-flex justify-content-end" style="height: 60px">
  <div class="navbar-brand d-flex justify-content-center ;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./login.php" class="home"> Home</a></div>
  
 
</nav>
</div>
</div>
</div>

<!-- nav end -->
<div class="container">
        <div class="row">
            <div class="col col-xl-5 col-md-6 col-6">
                <h3>DOCTER REGISTERATION</h3>
                <form action="" method="POST">
                    <label class="label">Name</label>
                    <input type="text" placeholder="Enter Your Name" auto-complete="off" name='name' required class="name"/><br/>
                    <label class="label">Contact</label>
                    <input type="number" placeholder="Enter Your Contact" auto-complete="off" name='contact num' required class="contact"/><br/>
                    <label class="label">Email</label>
                    <input type="email" placeholder="Enter Your Email" auto-complete="off" name='email' required class="contact"/><br/>
                    <label class="label">Specialist</label>
                    <input type="text" placeholder="Enter Your Field" auto-complete="off" name='specialistin' required class="contact"/><br/>
                    <label class="label">In</label>
                    <input type="text" placeholder="Enter Your In Time" auto-complete="off" name='intime' required class="contact"/><br/>
                    <label class="label">Out</label>
                    <input type="text" placeholder="Enter Your Out Time" auto-complete="off" name='outtime' required class="contact"/><br/>
                    <label class="label">Password</label>
                    <input type="text" placeholder="Enter Your Password" auto-complete="off" name='password' required class="contact"/><br/><br/><br/>
                    <button name="submit" class="button">Submit</button>
                </form>              
            </div>
        </div>
    </div>
    


<?php
 $con=mysqli_connect('localhost','root','','patient');
 //    database connct checking
    // if($con){
    //  echo 'connected';
    // }
    // else{
    //  echo 'not connected';
    // }


    if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $contact=$_POST['contact'];
        $email=$_POST['email'];
        $specialistin=$_POST['specialistin'];
        $intime=$_POST['intime'];
        $outtime=$_POST['outtime'];
        $password=$_POST['password'];
        $query="INSERT INTO doctordetial (name,contact,email,specialistin,intime,outtime,password) VALUES('$name','$contact','$email','$specialistin','$intime','$outtime','$password')";
    // data insert check
    
       if (mysqli_query($con,$query)){
            echo 'data inserted';
        }
        else{
            echo 'not inserted';
        }
    //    }

       
}





if(isset($_POST['submit'])){
    echo "<script> window.location.assign('./adminlogin.php')</script>";
   }
?>
<script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>
