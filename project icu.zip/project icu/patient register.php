<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Details </title>
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./p-reg.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="container-fluid">
  
  <div class="row ">
 
  <div class=" col col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 ">
  <nav class="navbar navbar-expand-lg navbar-light  col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end" style="height: 60px">
  <div class="navbar-brand d-flex justify-content-center ;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./login.php" class="btn-1"  style=""> Home</a></div>
  
 
</nav>
</div>
</div>
</div>



    <!-- nav end -->
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
            <h3>PATIENT REGISTER </h3><br>
                  <form method="POST" action="" enctype="multipart/form-data">
                    <label>USERNAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="text" name="username"  placeholder="Enter the name" auto-complete="off" required /><br><br>
                    <label>CONTACT NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="number" name="contact" placeholder="Enter the phone number" class="num" auto-complete="off" required /><br><br>
                    <label>EMAIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="email" name="email" placeholder="Enter the Email" auto-complete="off" required /><br><br>
                    <label>BLOOD GROUP&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="text" name="bloodgroup"placeholder="Enter the Blood Group" auto-complete="off" required /><br><br>
                    <label>PROBLEM DESCRIPTION &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="text" name="problemdescription" placeholder="Enter the text" auto-complete="off" required /><br><br>
                    <label>PASSWORD&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="password" name="password" placeholder="Enter the password" auto-complete="off" required /><br>
                    <input type="file" id="file" accept="image/*" name='image'/>
                    <label for="file" class="file">
                        <i class="fa-solid fa-file"></i>&nbsp;choosen file
                    </label><br/><br/><br/>
                    <button value="submit" name="submit" class="butt">SUBMIT</button>
                   
                  </form>
               
 
            </div>
        </div>
    </div>
    <?php

   if(isset($_POST['submit'])){
        $username=$_POST['username'];
        $contact=$_POST['contact'];
        $email=$_POST['email'];
        $bloodgroup=$_POST['bloodgroup'];
        $problemdescription=$_POST['problemdescription'];
        $password=$_POST['password'];

        $newfolder="picture/";

        $file_target=$newfolder.basename($_FILES["image"]['name']);
        $imagefiletype=strtolower(pathinfo($file_target,PATHINFO_EXTENSION));


        move_uploaded_file($_FILES["image"]['tmp_name'],$file_target);

        $con=mysqli_connect('localhost','root','','patient');

        $query="INSERT INTO patientdetials (username,contact,email,bloodgroup,problemdescription,password,image) VALUES ('$username','$contact','$email','$bloodgroup','$problemdescription','$password','$file_target')";
        $check=mysqli_query($con,$query);
        if($check){
            echo "<script>alert('Register Successfully')</script>";
        }
    else{
        echo "<script>alert('Register Failed')</script>";
    }

        // echo "<script> window.location.assign('http://localhost/task/project/project%20icu/patientlogin.php')</script>";
   }
     ?>
   
</body>
</html>