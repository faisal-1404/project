<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin profile</title>
    <link rel="stylesheet" href="./DOC-dash.css">
    <!-- <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css"> -->

    
</head>
<body>
<div class="container" align="center" style="margin-top:75px">
    <div class="row">
        <div class="col col-sm-12 col-md-12 col-lg-12">
   
            <div class="card"><br><br><br>
            <form method="post" action="">
            <h2><b>ADMIN PROFILE</b></h2><br>
                
                <button class="btn"><a href="./doctorreg.php" style="text-decoration: none; color:white;">doctor registation</a> </button><br><br><br>
                <!-- <button class="btn"><a href="./patient-doc%20-reg.php" style="text-decoration: none; color:white;"> doctor &patient register</a></button><br><br><br> -->
                <button class="btn"><a href="./allpatient.php" style="text-decoration: none; color:white;"> view patient</a></button><br><br><br>
                <button class="btn"><a  href="./alldoctor.php" style="text-decoration: none; color:white;"> view doctors</a></button><br><br><be>

                </form>

</div>
</div>
</div>

</div>
<script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>


                
    
</body>
</html>