<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="./admin.css">
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">

</head>
<body >
<div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
               <div class="bg">
                  <form class="f1" method="post" action="">
                    <h2>ADMIN</h2><br>
                    <label>USERNAME</lable><br/>
                    <input type="text" name="name" placeholder="Enter the name" auto-complete="off" required /><br><br>
                    <label>PASSWORD</lable><br/>
                    <input type="password" name="password" placeholder="Enter the password" auto-complete="off" required /><br><br><br>                
                    <button name="submit" class="button">Submit</button>   
                </form>
               </div>
            </div>
        </div>
    </div>
    <script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>

</body>
<?php
$con=mysqli_connect('localhost','root','','patient');

if(isset($_POST['submit'])){
    $username=$_POST['name'];
    $password=$_POST['password'];
    $querry="Select*from admin where username='$username'and password='$password'";
    $result=mysqli_query($con,$querry); 


    if(mysqli_num_rows($result)>0){
        $_SESSION['name']= $username;
        echo 'successfully LOGIN!';
        echo "<script>window.location.assign('http://localhost/project%20icu/adminprofile.php')</script>";

    }else{
        echo '<script>alert("invaild detials");</script>';
    }

}
?>

</html>