<?php
session_start();
if(isset($_POST['add']))
{
    $con=mysqli_connect('localhost','root','','patient');
    $select="SELECT * FROM doctordetial where id='$_POST[add]' ";
    $res=mysqli_query($con,$select);
    $fetch=mysqli_fetch_assoc($res);
    if(mysqli_num_rows($res)==1)
    {
        $ins=mysqli_query($con,"insert into patientfordoc (patient_name,patient_issue,doc_name,doc_spe) values ('$_SESSION[username]','$_SESSION[problemdescription]','$fetch[name]','$fetch[specialistin]')");
        if($ins)
        {
            echo '<script>window.location.href="DASHBOARD.php" ;alert("Doctor successfull regsiter for this patient");</script>';

        }
        else
        {
            echo '<script>alert("Something Wrong");</script>';

        }

    }
}
?>