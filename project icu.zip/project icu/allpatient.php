<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Detial</title>
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./allpatient.css">
   
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col col-sm-12 col-md-12 col-lg-8 col-xl-10 ">
            <h3>PATIENT VIEW</h3>
                <table class="table tab">
                    <tr>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>bloodgroup</th>
                        <th>problemdescription</th>
                        <th>Password</th>  
                    </tr>
       

    <?php
    $con=mysqli_connect('localhost','root','','patient');
    $query2="SELECT * FROM patientdetials";
    $value=mysqli_query($con,$query2);
    if(mysqli_num_rows($value)>0){
     while($row=mysqli_fetch_assoc($value)){
         echo "<tr><td>$row[username]</td>
         <td>$row[contact]</td>
         <td>$row[email]</td>
         <td>$row[bloodgroup]</td>
         <td>$row[problemdescription]</td>
         <td>$row[password]</td>


         </tr>";
    }
 }
 ?>
 </table>
</div>
</div>
</div>
 <script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
    
</body>
</html>