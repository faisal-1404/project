<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PATIENTLOGIN</title>
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./paitent.css">
    
</head>
<body>
<div class="container-fluid">
  
  <div class="row ">
 
  <div class=" col col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 ">
  <nav class="navbar navbar-expand-lg navbar-light  col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end" style="height: 60px">
  <div class="navbar-brand d-flex justify-content-center " >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./login.php"  class="home"> Home</a></div>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 
</nav>
</div>
</div>
</div>


    <!-- //--navbar ending -->
    <div class="container">
        <div class="row row_1">
            <div class="col-lg-12 col-md-12 col-12">
                <div class="bg">
                  <form class="f1" method="post" action="">
                    <h2>USER LOGIN</h2><br>
                    <label>USERNAME</lable><br/>
                    <input type="text" name="username" auto-complete="off" placeholder="Enter the name" required><br><br>
                    <label>PASSWORD</lable><br/>
                    <input type="password" name="password" auto-complete="off" placeholder="Enter the password" required><br>
                    <small>New User <a href="./patient register.php">Register Now</a></small><br><br>                
                    <button name="submit" class="button">Submit</button>   
                </form>
            </div>
            </div>
        </div>
    </div>

    <?php
$con=mysqli_connect('localhost','root','','patient');

if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $querry="Select*from patientdetials where username='$username'and password='$password'";
    $result=mysqli_query($con,$querry);
    $fetch=mysqli_fetch_assoc($result);

    if(mysqli_num_rows($result)>0){
        $_SESSION['username']= $username;
        $_SESSION['problemdescription']=$fetch['problemdescription'];
        echo 'successfully LOGIN!';
        echo "<script>window.location.assign('http://localhost/project%20icu/DASHBOARD.php')</script>";

    }else{
        echo '<script>alert("invaild detials");</script>';
    }

}


 


    ?>
     <script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
    
</body>
</html>            