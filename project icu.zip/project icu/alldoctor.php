<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docter Details</title>
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="./alldoctor.css">
       
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-xl-10 col-sm-12 col-md-12 col-lg-12">
            <h3>PATIENT VIEW</h3>
<table class="table  tab" >
        <tr>
            <th>Name</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Special Listin</th>
            <th>Intime</th>
            <th>Outtime</th>
           
            
        </tr>

       

    <?php
    $con=mysqli_connect('localhost','root','','patient');
    $query2="SELECT * FROM doctordetial";
    $value=mysqli_query($con,$query2);
    if(mysqli_num_rows($value)>0){
     while($row=mysqli_fetch_assoc($value)){
         echo "<tr><td>$row[name]</td>
         <td>$row[contact]</td>
         <td>$row[email]</td>
         <td>$row[specialistin]</td>
         <td>$row[intime]</td>
         <td>$row[outtime]</td>
        
    

         </tr>";
    }
 }
 ?>
 </table>
 </div>
</div>
</div>
 <script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>