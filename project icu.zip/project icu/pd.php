<?php
//  $querry= 'SELECT specialistin, COUNT(*) as count
// FROM doctordetial
// GROUP BY specialistin
// HAVING COUNT($_POST['specialistin']) > 1';

if(isset($_POST['add']))
{
echo $_POST['add'];
}

?>

