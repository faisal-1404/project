<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="./navbar.css">
  <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css">
  <style>

  </style>
</head>
<body>

  <div class="container-fluid">
  
    <div class="row">
   
    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12  ">
    <nav class="navbar navbar-expand-lg  col-sm-12 col-md-12 col-lg-12 navi">
    <div class="navbar-brand " >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GESTURE BASED VOICE MESSAGE SYSTEM FOR PATIENT</div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse   dd navbar-collapse  " id="navbarNavDropdown" >
      <ul class="navbar-nav">
        
        <li class="nav-item  dropdown ">
          <a class="nav-link dl dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Login
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" >
            <li><a class="dropdown-item" href="./patientlogin.php">User login</a></li>
            <li><a class="dropdown-item" href="./adminlogin.php">Admin login</a></li>
            
          </ul>
        </li>
      </ul>
    </div>
</nav>
</div>
  </div>
</div>




</body>
</html>












  