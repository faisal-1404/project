<!DOCTYPE html>
<html lang="en">
<head>
    <title>Patient Docter Detail</title>
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="./patient-doc.css">
   
</head>
<body>
<?php
 $con=mysqli_connect('localhost','root','','patient');
$select=mysqli_query($con,"select * from patientdetials");
while($row=mysqli_fetch_assoc($select))
{
    ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                <form action="pd.php" method="post">
                    <h5><?php echo $row['username'];?></h5>
                    <p><?php echo $row['problemdescription'] ?></p>
                    <button type="submit" name="add" value="<?php echo $row['problemdescription'] ?>" class="btn btn-primary">+Add Doctor</button>
                </form>
            </div>
        </div>
    </div>
<?php
}
?>
    <script src="./bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>