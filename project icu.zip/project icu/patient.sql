-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2023 at 09:56 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patient`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `doctordetial`
--

CREATE TABLE `doctordetial` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(300) NOT NULL,
  `specialistin` varchar(300) NOT NULL,
  `intime` varchar(30) NOT NULL,
  `outtime` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctordetial`
--

INSERT INTO `doctordetial` (`id`, `name`, `contact`, `email`, `specialistin`, `intime`, `outtime`, `password`) VALUES
(1, 'suba', '1234567890', 'suba@gamil', 'eye', '9.00', '10.00', '1234'),
(2, 'abi', '99653548576', 'abi@gmail.com', 'heart', '9.00', '10.00', '1229'),
(3, 'arjun', '1234567890', 'arjun@gmail.com', 'fever', '9.00', '10.00', '8888'),
(4, 'vinoth', '99653548576', 'vinoth@gamil.com', 'fever', '9.00', '10.00', '9090'),
(5, 'aasika', '9923451245', 'aasika@gmail.com', 'fever', '9.00', '2.00', '7777'),
(6, 'karthik', '99653548576', 'karthik@gmail.com', 'fever', '9.00', '10.00', '123456'),
(7, 'BAWA', '9965209852', 'karthiksundar20@gamail.com', 'mouth and teeth', '9.00', '11.00', 'BAWA@2121');

-- --------------------------------------------------------

--
-- Table structure for table `patientdetials`
--

CREATE TABLE `patientdetials` (
  `username` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `bloodgroup` varchar(10) NOT NULL,
  `problemdescription` varchar(300) NOT NULL,
  `password` varchar(30) NOT NULL,
  `image` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientdetials`
--

INSERT INTO `patientdetials` (`username`, `contact`, `email`, `bloodgroup`, `problemdescription`, `password`, `image`) VALUES
('faisal', '9600847668', 'faisalahamed0804@gmail.com', 'O+', 'fever', '9600', 'picture/20.jpg'),
('Mr.Pink', '9966778877', 'Pinklover143@gmail.com', 'B+ve', 'Sickness', '56657869', 'picture/bulb.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `patientdoctor`
--

CREATE TABLE `patientdoctor` (
  `patient` varchar(300) NOT NULL,
  `doctor` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientdoctor`
--

INSERT INTO `patientdoctor` (`patient`, `doctor`) VALUES
('raja', 'suba');

-- --------------------------------------------------------

--
-- Table structure for table `patientfordoc`
--

CREATE TABLE `patientfordoc` (
  `id` int(11) NOT NULL,
  `patient_name` varchar(200) NOT NULL,
  `patient_issue` varchar(200) NOT NULL,
  `doc_name` varchar(200) NOT NULL,
  `doc_spe` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientfordoc`
--

INSERT INTO `patientfordoc` (`id`, `patient_name`, `patient_issue`, `doc_name`, `doc_spe`) VALUES
(1, 'faisal', 'fever', 'arjun', 'fever');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctordetial`
--
ALTER TABLE `doctordetial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patientfordoc`
--
ALTER TABLE `patientfordoc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctordetial`
--
ALTER TABLE `doctordetial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `patientfordoc`
--
ALTER TABLE `patientfordoc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
