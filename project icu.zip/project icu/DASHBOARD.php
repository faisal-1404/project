<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dash Board</title>
    <link rel="stylesheet" href="./register.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="./bootstrap-5.0.2-dist/css/bootstrap.min.css" />
  </head>
  <body>
<nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <!-- <a class="navbar-brand" href="#">SMART LOCKER SECURITY SYSTEM</a> -->
 <h3 class="fs-4 ms-4">GESTURE BASED VOICE MESSAGE SYSTEM FOR PATIENT
</h3>
      <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Features</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Pricing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
          </li>
        </ul> -->
    </div>
  </div>
</nav>
  <!-- bootstrap ending -->
    <div class="container mt-5">
      <div class="row">
        <div class="col-lg-3 sidebar">
          <?php
            $con=mysqli_connect('localhost','root','','patient');
            $select="SELECT * FROM patientdetials where username='$_SESSION[username]'";
            $result=mysqli_query($con,$select);
            $row=mysqli_fetch_assoc($result);
            $numrow=mysqli_num_rows($result);

          ?>
          <div class="image">
              <img class="img-1" src="./<?php echo $row['image'];?>" alt="hellpo" />
          </div>
          <h5>Name:<?php echo $row['username'];?></h5>
          <form action="" class="formText" method="post">
          <div class=" text-center">
            <button class="btn  bt btn-lg rounded-pill  mb-3" name="view" value="$_SESSION['username']"  type="submit">View Details</button>
          </div>
          <div class=" text-center">
            <button class="btn  bt btn-lg rounded-pill mb-3" name="setdocter">Set Docter</button>
          </div>
          <div class=" text-center">
            <button class="btn  bt btn-lg rounded-pill mb-3" name="viewdocter">View Docter</button>
          </div>
          <div class=" text-center">
            <button class="btn  bt btn-lg rounded-pill mb-3">Sensor Data</button>
          </div>
          <div class=" text-center">
            <button class="btn  bt btn-lg rounded-pill mb-3" name="logout">Logout</button>
          </div>
          </form>
        </div>
        <div class="col-lg-9">
          <div class="table-color">
            <?php
            if(isset($_POST['view']))
            {
              ?>
              <div class="container">
                <div class="row p-5 justify-content-center">
                  <div class="col-lg-12 ">
                    <div class="table-2 text-center">
                       <div class="table">
                       <?php 
                       if($numrow==1){
                      ?>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:15px;">
                                Name
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                                <?php echo $row['username'];?>
                              </div>
                              </div>
                          </li>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:25px;">
                                Contact
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                                <?php echo $row['contact'];?>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:10px";>
                                Email
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                                <?php echo $row['email'];?>
                              </div>
                            </div>
                          </li>
                          <li>
                          <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:60px;">
                                Blood Group
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                                <?php echo $row['bloodgroup'];?>
                              </div>
                              </div>
                          </li>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:105px;">
                                &nbsp;&nbsp;&nbsp;Problem Description
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                                <?php echo $row['problemdescription'];?>
                              </div>
                              </div>
                          </li>                                                   
                        <?php
                          }
                        
                        ?>
                         <tbody>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php
            }
            ?>
            <?php
              if(isset($_POST['setdocter'])){
                ?>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class=" text-center">
                        <div class="table-color ">
                        <form action="pfd.php" class="c1" method="post">
                        <?php
                        $con=mysqli_connect('localhost','root','','patient');

                        $select="SELECT * FROM patientfordoc WHERE patient_name='$_SESSION[username]'";

                        $check=mysqli_query($con,$select);


                        if(mysqli_num_rows($check)==1){
                          echo "<script>alert('You are Not Allowed');</script>";
                        }

                        else{

                        $select="SELECT * FROM doctordetial where specialistin='$_SESSION[problemdescription]'";
                        $result=mysqli_query($con,$select);
                        while($row=mysqli_fetch_assoc($result))
                        {
                          ?>
                       <?php 
                      ?>
                          <li>
                       <?php 
                       if($numrow==1){
                      ?>
                          <li>
                            
                            <div class = 'row p-3 justify-content-center' >
                              <div class='col-4 text-center'>
                              Doctor Name:<?php echo $row['name'];?>
                              </div>
                              <div class='col-4 text-center'>
                              Specialist:<?php echo $row['specialistin']; ?>
                              </div>
                              <div class='col-4 text-center'>
                              <button type="submit" value="<?php echo $row['id']; ?>" name="add" class="btn btn-primary">Add Doctor</button>
                              </div>
                            </div>
                          <?php
                        }
                      }
                    }
                        ?>
                        
                        </form>
                      </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php

              }
            ?>

            <?php
              if(isset($_POST['viewdocter'])){
                $con=mysqli_connect('localhost','root','','patient');

                $select="SELECT * FROM patientfordoc WHERE patient_name='$_SESSION[username]'";

                $check=mysqli_query($con,$select);

                $row=mysqli_fetch_assoc($check);

                if(mysqli_num_rows($check)==1){
                  ?>
                  <div class="container">
                <div class="row p-5 justify-content-center">
                  <div class="col-lg-12 ">
                    <div class="table-2 text-center">
                       <div class="table">
                       <?php 
                       if($numrow==1){
                      ?>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:155px;">
                                Patient Name
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                              <?php echo $row['patient_name']; ?>
                              </div>
                              </div>
                          </li>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:150px;">
                               Patient Issue
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                              <?php echo $row['patient_issue']; ?>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class = 'row' >
                              <div class='col-5 text-center' style="padding-left:152px;">
                               Docter Name
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                              <?php echo $row['doc_name']; ?>
                              </div>
                            </div>
                          </li>
                          <li>
                          <div class = 'row' >
                              <div class='col-5 text-start' style="padding-left:177px;">
                                Specialist
                              </div>
                              <div class='col-2 text-center'>
                                :
                              </div>
                              <div class='col-5 text-start'>
                              <?php echo $row['doc_spe']; ?>
                              </div>
                              </div>
                          </li>                                                  
                  <?php
                }

                else{
                  echo "<script>alert('No Set Docter');</script>";
                }
              }
            }
            ?>

            <?php
              if(isset($_POST["logout"])){
                echo "<script>window.location.assign('http://localhost/project%20icu/patientlogin.php')</script>";
              }
            ?>
          </div>
        </div>
      </div>
    </div>
    
        
     
</body>
</html>